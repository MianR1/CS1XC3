/**
 * @file course.h
 * @author rafaym1
 * @brief This file creates the course typedef used in the .c files. This is what initallizes the course
 * @version 1
 * @date 2022-04-09
 */

#include "student.h"
#include <stdbool.h>
// creation of course
typedef struct _course 
{
  char name[100];
  char code[10];
  Student *students;
  int total_students;
} Course;


/**
 * @brief defining the functions which are called in other.c files so that they can be called from the other files
 * @param student A pointer which holds all of a students information 
 * @param course A pointer which holds all of the courses information 
 * @param total_passing A pointer which holds the total number of students passing the course
 */

void enroll_student(Course *course, Student *student);
void print_course(Course *course);
Student *top_student(Course* course);
Student *passing(Course* course, int *total_passing);


