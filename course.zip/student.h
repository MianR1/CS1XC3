/**
* @file student.h
* @author rafaym1
* @brief This file creates the student typedef used in the .c files. This is what initallizes the student
* @version 1
* @date 2022-04-09
*/
typedef struct _student 
{ 
  char first_name[50];
  char last_name[50];
  char id[11];
  double *grades; 
  int num_grades; 
} Student;

/**
 * @brief defining the functions which are called in other.c files so that they can be called from the other files
 * @param student A pointer which holds all of a students information 
 * @param course A pointer which holds all of the courses information 
 * @param generate_random_student A pointer which generates a random student
 */

void add_grade(Student *student, double grade);
double average(Student *student);
void print_student(Student *student);
Student* generate_random_student(int grades); 
