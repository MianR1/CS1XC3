/**
 * @file course.c
 * @author rafaym1
 * @brief This file holds the functions which are used to get information about the students/courses.
 * @version 1
 * @date 2022-04-09
 */

#include "course.h"
#include <stdlib.h>
#include <stdio.h>

// Function to enroll student into course
void enroll_student(Course *course, Student *student)
{ 
  // adds 1 to the number of total students in the course
  course->total_students++;
  /*
  Sets the size of the students dynamic array within the course to be equal to 1
  as the if checks if the size is equal to 1
  */
  if (course->total_students == 1) 
  {
    course->students = calloc(1, sizeof(Student));
  }
  else 
  /*
  Resets the size of the students dynamic array within the course to be equal to the 
  total number of students enrolled in the course
  */
  {
    course->students = 
      realloc(course->students, course->total_students * sizeof(Student)); 
  }
  course->students[course->total_students - 1] = *student;
}

// Prints course Information
void print_course(Course* course)
{
  printf("Name: %s\n", course->name);
  printf("Code: %s\n", course->code);
  printf("Total students: %d\n\n", course->total_students);
  printf("****************************************\n\n");
  for (int i = 0; i < course->total_students; i++) 
    print_student(&course->students[i]);
}

// Gets student with the highest mark and returns it
Student* top_student(Course* course)
{
  // returns NULL if no students are enroled into the course
  if (course->total_students == 0) return NULL;
 
  double student_average = 0;
  // sets max average to the first student in the course
  double max_average = average(&course->students[0]);
  Student *student = &course->students[0];
 
  for (int i = 1; i < course->total_students; i++)
  {
    student_average = average(&course->students[i]);
    // cycles through students to find the student with the highest average
    if (student_average > max_average) 
    {
      max_average = student_average;
      student = &course->students[i];
    }   
  }

  return student;
}

// Determines if the student is passing the course
Student *passing(Course* course, int *total_passing)
{
  int count = 0;
  Student *passing = NULL;
  
  for (int i = 0; i < course->total_students; i++) 
    if (average(&course->students[i]) >= 50) count++;
  
  // initallizes a passing list using calloc
  passing = calloc(count, sizeof(Student));

  int j = 0;
  for (int i = 0; i < course->total_students; i++)
  {
    // if students average is equal to or above 50 than he is added to the passing list
    if (average(&course->students[i]) >= 50)
    {
      passing[j] = course->students[i];
      j++; 
    }
  }

  *total_passing = count;

  return passing;
}